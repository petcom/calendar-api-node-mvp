[] https://medium.com/@nitishkmrk/design-tokens-beginners-guide-4424944bf5f9
[] https://polaris.shopify.com/design/colors
[] https://tr.designtokens.org/
[] https://origami.ft.com/